import React, { useState } from 'react';
import { Building2, Database, SendHorizontal, CheckCircle } from 'lucide-react';

interface OrderPoint {
  número: string;
  punto: string;
}

interface ApiResponse {
  orden_del_dia: OrderPoint[];
}

function App() {
  const [loading, setLoading] = useState(false);
  const [orderPoints, setOrderPoints] = useState<OrderPoint[]>([]);
  const [selectedPoints, setSelectedPoints] = useState<Set<string>>(new Set());
  const [showSuccess, setShowSuccess] = useState(false);

  const queryDatabase = async () => {
    setLoading(true);
    setShowSuccess(false);
    try {
      const response = await fetch('https://hook.us2.make.com/qmy5bcj5odq12qdairrwh5q8qe55tpp7', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'query'
        })
      });
      
      const data: ApiResponse = await response.json();
      setOrderPoints(data.orden_del_dia || []);
      setSelectedPoints(new Set());
    } catch (error) {
      alert('Error al realizar la consulta');
      setOrderPoints([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (selectedPoints.size === 0) {
      alert('Por favor seleccione al menos un punto para enviar a OCS');
      return;
    }

    setLoading(true);
    try {
      const pointsToSend = orderPoints.filter(point => selectedPoints.has(point.número));
      const response = await fetch('https://hook.us2.make.com/2a4pyj6ifykd6bddyklaaxi5cklzfxtq', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'submit',
          orden_del_dia: pointsToSend
        })
      });
      
      if (!response.ok) {
        throw new Error('Error al enviar los datos');
      }
      
      setShowSuccess(true);
      setOrderPoints([]);
      setSelectedPoints(new Set());
    } catch (error) {
      alert('Error al enviar los datos');
    } finally {
      setLoading(false);
    }
  };

  const togglePointSelection = (number: string) => {
    const newSelected = new Set(selectedPoints);
    if (newSelected.has(number)) {
      newSelected.delete(number);
    } else {
      newSelected.add(number);
    }
    setSelectedPoints(newSelected);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F5F7FA' }}>
        <div className="text-center space-y-4 py-12">
          <CheckCircle className="w-16 h-16 text-[#006d2c] mx-auto" />
          <h2 className="text-2xl font-bold text-[#1C3247]">¡Enviado Exitosamente!</h2>
          <p className="text-gray-600">
            Muchas gracias!.
          </p>
          <button
            onClick={() => setShowSuccess(false)}
            className="mt-4 px-6 py-2 bg-unemi-blue text-white rounded-lg hover:opacity-90"
          >
            Volver
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white font-avenir">
      <header className="bg-unemi-blue py-4">
        <div className="container mx-auto px-4 flex items-center gap-4">
          <Building2 size={48} className="text-white" />
          <span className="text-white font-avenir text-2xl">UNEMI</span>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-end space-x-4 mb-6">
          <button
            className="px-4 py-2 bg-unemi-orange text-white rounded-lg hover:opacity-90 flex items-center gap-2"
            onClick={queryDatabase}
            disabled={loading}
          >
            <Database className="w-5 h-5" />
            Consultar datos
          </button>
          <button
            className="px-4 py-2 bg-unemi-green text-white rounded-lg hover:opacity-90 flex items-center gap-2"
            onClick={handleSubmit}
            disabled={loading}
          >
            <SendHorizontal className="w-5 h-5" />
            Enviar a OCS
          </button>
        </div>

        {loading ? (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-unemi-blue mx-auto"></div>
              <p className="mt-4 text-center text-gray-700">Cargando...</p>
            </div>
          </div>
        ) : (
          <div>
            <h2 className="text-xl font-semibold mb-4 text-unemi-blue">
              Puntos Tratados en Comisión de Gestión Académica
            </h2>
            {orderPoints.length === 0 ? (
              <div className="bg-white rounded-lg p-8 text-center shadow-sm">
                <p className="text-lg text-gray-600">No existen registros de puntos de CGA</p>
              </div>
            ) : (
              <>
                <p className="text-gray-600 mb-4">
                  Marque los puntos que desea enviar a OCS
                </p>
                <div className="space-y-4">
                  {orderPoints.map((point) => (
                    <div key={point.número} className="border rounded-lg p-4 mb-4 shadow-sm bg-white">
                      <div className="flex items-start gap-4">
                        <input
                          type="checkbox"
                          id={`point-${point.número}`}
                          checked={selectedPoints.has(point.número)}
                          onChange={() => togglePointSelection(point.número)}
                          className="mt-1.5 h-4 w-4 rounded border-gray-300 text-unemi-blue focus:ring-unemi-blue"
                        />
                        <label
                          htmlFor={`point-${point.número}`}
                          className="flex-1 font-semibold text-lg text-gray-800 cursor-pointer"
                        >
                          {point.número}. {point.punto}
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;