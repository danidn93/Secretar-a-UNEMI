import React from 'react';
import { useForm } from 'react-hook-form';
import { Calendar, Clock, MapPin, Building2 } from 'lucide-react';

interface MeetingForm {
  title: string;
  date: string;
  time: string;
  location: string;
  type: 'OCS' | 'CGA';
}

function App() {
  const { register, handleSubmit } = useForm<MeetingForm>();

  const onSubmit = async (data: MeetingForm) => {
    // Replace this URL with your actual webhook URL
    const webhookUrl = 'YOUR_WEBHOOK_URL';
    
    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
    } catch (error) {
      console.error('Error sending webhook:', error);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#1C3247] py-4">
        <div className="container mx-auto px-4 flex items-center gap-4">
          <Building2 size={48} className="text-white" />
          <span className="text-white font-aventura text-2xl">UNEMI</span>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="title text-4xl text-[#1C3247] mb-8">Agenda de Reuniones</h1>
        
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit(onSubmit)} className="bg-white rounded-lg shadow-lg p-6">
            <div className="space-y-4">
              <div>
                <label className="block text-[#1C3247] mb-2">Nombre de la Reunión</label>
                <input
                  {...register('title', { required: true })}
                  className="w-full border border-gray-300 rounded-md p-2"
                />
              </div>

              <div>
                <label className="block text-[#1C3247] mb-2">Fecha</label>
                <div className="relative">
                  <Calendar className="absolute left-2 top-2.5 text-gray-500" size={20} />
                  <input
                    type="date"
                    {...register('date', { required: true })}
                    className="w-full border border-gray-300 rounded-md p-2 pl-10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#1C3247] mb-2">Hora</label>
                <div className="relative">
                  <Clock className="absolute left-2 top-2.5 text-gray-500" size={20} />
                  <input
                    type="time"
                    {...register('time', { required: true })}
                    className="w-full border border-gray-300 rounded-md p-2 pl-10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#1C3247] mb-2">Lugar</label>
                <div className="relative">
                  <MapPin className="absolute left-2 top-2.5 text-gray-500" size={20} />
                  <input
                    {...register('location', { required: true })}
                    className="w-full border border-gray-300 rounded-md p-2 pl-10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#1C3247] mb-2">Tipo</label>
                <select
                  {...register('type', { required: true })}
                  className="w-full border border-gray-300 rounded-md p-2"
                >
                  <option value="OCS">OCS</option>
                  <option value="CGA">CGA</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-[#fe9900] hover:bg-[#e88a00] text-white font-bold py-2 px-4 rounded-md"
              >
                Agendar Reunión
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}

export default App;