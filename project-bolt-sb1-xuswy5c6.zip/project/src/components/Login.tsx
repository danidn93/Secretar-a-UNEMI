import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Lock, User, Building2 } from 'lucide-react';

export function Login() {
  const [email, setEmail] = useState('admin');
  const [password, setPassword] = useState('admin');
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'admin' && password === 'admin') {
      await signIn();
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-[#1C3247] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Building2 size={48} className="text-[#1C3247]" />
            <span className="text-[#1C3247] font-aventura text-2xl">UNEMI</span>
          </div>
          <h2 className="text-2xl font-aventura text-[#1C3247]">
            Iniciar Sesión
          </h2>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Usuario
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#fe9900] focus:border-[#fe9900]"
                placeholder="Usuario"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Contraseña
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#fe9900] focus:border-[#fe9900]"
                placeholder="Contraseña"
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-3 px-4 bg-[#fe9900] text-white rounded-lg hover:bg-[#e88a00] transition-colors font-medium"
          >
            Ingresar
          </button>
        </form>
      </div>
    </div>
  );
}