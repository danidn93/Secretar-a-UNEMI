import React from 'react';
import { LogOut, Building2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export function Layout({ children }: { children: React.ReactNode }) {
  const { signOut } = useAuth();

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#1C3247] py-4">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Building2 size={48} className="text-white" />
            <span className="text-white font-aventura text-2xl">UNEMI</span>
          </div>
          <button
            onClick={signOut}
            className="flex items-center px-4 py-2 text-white bg-[#fe9900] rounded-lg hover:bg-[#e88a00] transition-colors"
          >
            <LogOut className="w-5 h-5 mr-2" />
            Cerrar Sesión
          </button>
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
}