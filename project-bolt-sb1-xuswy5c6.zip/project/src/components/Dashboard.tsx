import React, { useState } from 'react';
import { FileText, Search, Calendar, FileSpreadsheet } from 'lucide-react';
import { Modal } from './Modal';

export function Dashboard() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  const modules = [
    {
      title: 'Crear Agenda',
      icon: Calendar,
      url: 'https://peppy-griffin-c78e7f.netlify.app/',
      color: '#1C3247'
    },
    {
      title: 'Agregar Puntos de Orden',
      icon: FileText,
      url: 'https://sunny-torte-32072d.netlify.app/',
      color: '#006d2c'
    },
    {
      title: 'Consultar Puntos de Orden',
      icon: Search,
      url: 'https://keen-malabi-ba6d20.netlify.app/',
      color: '#fe9900'
    },
    {
      title: 'CGA a OCS',
      icon: FileSpreadsheet,
      url: 'https://taupe-dango-16d600.netlify.app/',
      color: '#2563eb'
    }
  ];

  return (
    <>
      <div className="flex justify-center items-center gap-4 px-4 min-h-[calc(100vh-8rem)]">
        {modules.map((module, index) => {
          const Icon = module.icon;
          return (
            <button
              key={index}
              onClick={() => setSelectedModule(module.url)}
              className="transition-transform duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 rounded-lg"
            >
              <div
                className="rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col items-center justify-center gap-2"
                style={{ 
                  backgroundColor: module.color,
                  width: '142px',
                  height: '120px'
                }}
              >
                <Icon className="w-8 h-8 text-white" />
                <span className="text-white text-sm text-center font-aventura px-2 line-clamp-2">
                  {module.title}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <Modal
        isOpen={selectedModule !== null}
        onClose={() => setSelectedModule(null)}
        url={selectedModule || ''}
      />
    </>
  );
}