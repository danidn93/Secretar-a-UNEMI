import { useState, createContext, useContext, useEffect, useCallback, useRef } from 'react';
import type { ReactNode } from 'react';
import { supabase } from '../lib/supabase';

type AuthContextType = {
  session: any;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
};

const INACTIVITY_TIMEOUT = 5 * 60 * 1000; // 5 minutes in milliseconds

const AuthContext = createContext<AuthContextType>({
  session: null,
  signIn: async () => {},
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<any>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const sessionRef = useRef(session);

  // Update session ref when session changes
  useEffect(() => {
    sessionRef.current = session;
  }, [session]);

  const clearInactivityTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const signOut = useCallback(async () => {
    setSession(null);
    clearInactivityTimer();
  }, [clearInactivityTimer]);

  const resetInactivityTimer = useCallback(() => {
    clearInactivityTimer();
    if (sessionRef.current) {
      timerRef.current = setTimeout(signOut, INACTIVITY_TIMEOUT);
    }
  }, [clearInactivityTimer, signOut]);

  useEffect(() => {
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    if (!session) return;

    const handleUserActivity = () => {
      resetInactivityTimer();
    };

    events.forEach(event => {
      document.addEventListener(event, handleUserActivity);
    });
    
    resetInactivityTimer();

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handleUserActivity);
      });
      clearInactivityTimer();
    };
  }, [session, resetInactivityTimer, clearInactivityTimer]);

  const signIn = useCallback(async () => {
    setSession({ user: { email: 'admin' } });
  }, []);

  return (
    <AuthContext.Provider value={{ session, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  return useContext(AuthContext);
};