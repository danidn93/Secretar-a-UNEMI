export interface PuntoOrden {
  id: string;
  numero: number;
  punto: string;
  estado: 'pendiente' | 'eliminado' | 'cambios_solicitados' | 'aprobado' | 'agregado';
  cambios?: string;
}

export interface EstadoAgenda {
  puntos: PuntoOrden[];
  puntosOriginales: PuntoOrden[];
  agregarPunto: (punto: Omit<PuntoOrden, 'id' | 'estado'>) => void;
  eliminarPunto: (id: string) => void;
  solicitarCambios: (id: string, cambios: string) => void;
  inicializarPuntos: (puntos: Array<{ numero: number; punto: string }>) => void;
  limpiarPuntos: () => void;
}

export interface DatosIniciales {
  FileName?: string;
  Data?: string;
  orden_del_dia: Array<{
    número: number;
    punto: string;
  }>;
}

export interface RespuestaGuardado {
  success: boolean;
  message: string;
}

export type TipoReunion = 'CGA' | 'OCS';