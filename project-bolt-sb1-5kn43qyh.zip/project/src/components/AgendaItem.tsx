import React, { useState } from 'react';
import { Check, X, MessageSquare } from 'lucide-react';
import { AgendaItem as AgendaItemType } from '../types';

interface AgendaItemProps {
  item: AgendaItemType;
  onApprove: (id: string) => void;
  onRequestChanges: (id: string, changes: string) => void;
  onRemove: (id: string) => void;
}

export const AgendaItem: React.FC<AgendaItemProps> = ({
  item,
  onApprove,
  onRequestChanges,
  onRemove,
}) => {
  const [changes, setChanges] = useState('');
  const [showChangesInput, setShowChangesInput] = useState(false);

  return (
    <div className="border rounded-lg p-4 mb-4 bg-white shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold text-lg">{item.title}</h3>
          <p className="text-gray-600 mt-1">{item.description}</p>
          {item.status === 'changes_requested' && item.changes && (
            <div className="mt-2 p-2 bg-yellow-50 rounded">
              <p className="text-sm text-yellow-700">
                Suggested changes: {item.changes}
              </p>
            </div>
          )}
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => onApprove(item.id)}
            className="p-2 text-green-600 hover:bg-green-50 rounded"
            title="Approve"
          >
            <Check size={20} />
          </button>
          <button
            onClick={() => setShowChangesInput(!showChangesInput)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded"
            title="Request changes"
          >
            <MessageSquare size={20} />
          </button>
          <button
            onClick={() => onRemove(item.id)}
            className="p-2 text-red-600 hover:bg-red-50 rounded"
            title="Remove"
          >
            <X size={20} />
          </button>
        </div>
      </div>
      {showChangesInput && (
        <div className="mt-4">
          <textarea
            value={changes}
            onChange={(e) => setChanges(e.target.value)}
            className="w-full p-2 border rounded"
            placeholder="Suggest changes..."
            rows={3}
          />
          <div className="mt-2 flex justify-end space-x-2">
            <button
              onClick={() => {
                onRequestChanges(item.id, changes);
                setChanges('');
                setShowChangesInput(false);
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Submit Changes
            </button>
            <button
              onClick={() => {
                setChanges('');
                setShowChangesInput(false);
              }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};