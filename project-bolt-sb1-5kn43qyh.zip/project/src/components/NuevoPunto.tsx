import React, { useState } from 'react';
import { Plus } from 'lucide-react';

interface NuevoPuntoProps {
  onAgregar: (punto: { numero: number; punto: string }) => void;
  siguienteNumero: number;
}

export const NuevoPunto: React.FC<NuevoPuntoProps> = ({ onAgregar, siguienteNumero }) => {
  const [mostrarForm, setMostrarForm] = useState(false);
  const [punto, setPunto] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (punto.trim()) {
      onAgregar({ numero: siguienteNumero, punto: punto.trim() });
      setPunto('');
      setMostrarForm(false);
    }
  };

  return (
    <div className="mb-6">
      {!mostrarForm ? (
        <button
          onClick={() => setMostrarForm(true)}
          className="flex items-center space-x-2 px-4 py-2 text-white rounded-lg hover:opacity-90"
          style={{ backgroundColor: '#1C3247' }}
        >
          <Plus size={20} />
          <span>Agregar Nuevo Punto</span>
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="bg-white p-4 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold mb-4">Nuevo Punto del Orden del Día</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: '#1C3247' }}>
                Punto #{siguienteNumero}
              </label>
              <textarea
                value={punto}
                onChange={(e) => setPunto(e.target.value)}
                className="w-full p-2 border rounded"
                placeholder="Descripción del punto..."
                rows={3}
                required
              />
            </div>
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setMostrarForm(false)}
                className="px-4 py-2 text-white rounded hover:opacity-90"
                style={{ backgroundColor: '#1C3247' }}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-white rounded hover:opacity-90"
                style={{ backgroundColor: '#fe9900' }}
              >
                Agregar Punto
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};