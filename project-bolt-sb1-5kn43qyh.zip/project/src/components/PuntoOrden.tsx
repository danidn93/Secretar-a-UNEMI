import React, { useState } from 'react';
import { X, MessageSquare } from 'lucide-react';
import { PuntoOrden as PuntoOrdenType } from '../types';

interface PuntoOrdenProps {
  punto: PuntoOrdenType;
  onSolicitarCambios: (id: string, cambios: string) => void;
  onEliminar: (id: string) => void;
}

export const PuntoOrden: React.FC<PuntoOrdenProps> = ({
  punto,
  onSolicitarCambios,
  onEliminar,
}) => {
  const [cambios, setCambios] = useState('');
  const [mostrarInputCambios, setMostrarInputCambios] = useState(false);

  const estiloTexto = punto.estado === 'eliminado' 
    ? 'line-through text-gray-500' 
    : 'text-gray-800';

  return (
    <div 
      className="border rounded-lg p-4 mb-4 shadow-sm bg-white"
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className={`font-semibold text-lg ${estiloTexto}`}>
            {punto.numero}. {punto.punto}
          </h3>
          {punto.estado === 'cambios_solicitados' && punto.cambios && (
            <div className="mt-2 p-2 rounded" style={{ backgroundColor: '#FFF3E0' }}>
              <p className="text-sm" style={{ color: '#1C3247' }}>
                Cambios sugeridos: {punto.cambios}
              </p>
            </div>
          )}
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setMostrarInputCambios(!mostrarInputCambios)}
            className="p-2 rounded hover:bg-opacity-90"
            style={{ color: '#fe9900' }}
            title="Solicitar cambios"
          >
            <MessageSquare size={20} />
          </button>
          <button
            onClick={() => onEliminar(punto.id)}
            className="p-2 rounded hover:bg-opacity-90"
            style={{ color: '#1C3247' }}
            title="Eliminar"
          >
            <X size={20} />
          </button>
        </div>
      </div>
      {mostrarInputCambios && (
        <div className="mt-4">
          <textarea
            value={cambios}
            onChange={(e) => setCambios(e.target.value)}
            className="w-full p-2 border rounded"
            placeholder="Sugerir cambios..."
            rows={3}
          />
          <div className="mt-2 flex justify-end space-x-2">
            <button
              onClick={() => {
                onSolicitarCambios(punto.id, cambios);
                setCambios('');
                setMostrarInputCambios(false);
              }}
              className="px-4 py-2 text-white rounded hover:opacity-90"
              style={{ backgroundColor: '#fe9900' }}
            >
              Enviar Cambios
            </button>
            <button
              onClick={() => {
                setCambios('');
                setMostrarInputCambios(false);
              }}
              className="px-4 py-2 text-white rounded hover:opacity-90"
              style={{ backgroundColor: '#1C3247' }}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};