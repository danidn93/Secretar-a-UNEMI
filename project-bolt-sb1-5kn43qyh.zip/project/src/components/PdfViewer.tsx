import React, { useEffect, useState } from 'react';
import { Worker, Viewer } from '@react-pdf-viewer/core';
import { defaultLayoutPlugin } from '@react-pdf-viewer/default-layout';
import '@react-pdf-viewer/core/lib/styles/index.css';
import '@react-pdf-viewer/default-layout/lib/styles/index.css';
import { AlertCircle } from 'lucide-react';

interface PdfViewerProps {
  url: string | null;
  fileName?: string;
}

export const PdfViewer: React.FC<PdfViewerProps> = ({ url, fileName }) => {
  const defaultLayoutPluginInstance = defaultLayoutPlugin();
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadPdf = async () => {
      if (!url) {
        setPdfUrl(null);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        if (url.includes('drive.google.com')) {
          const fileId = url.match(/id=([^&]+)/)?.[1];
          if (fileId) {
            setPdfUrl(`https://drive.google.com/uc?export=view&id=${fileId}`);
          } else {
            throw new Error('ID de archivo no válido');
          }
        } else {
          setPdfUrl(url);
        }
      } catch (err) {
        setError('No se pudo cargar el archivo PDF. Por favor, verifica la URL e intenta nuevamente.');
      } finally {
        setLoading(false);
      }
    };

    loadPdf();
  }, [url]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg border border-gray-200">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" style={{ borderColor: '#1C3247' }}></div>
          <p className="text-gray-600">Cargando documento...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-96 bg-red-50 rounded-lg border border-red-200">
        <div className="text-center px-6">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-red-700 font-medium mb-2">Error al cargar el documento</p>
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  if (!pdfUrl) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg border border-gray-200">
        <div className="text-center px-6">
          <p className="text-gray-500">No se ha cargado ningún documento</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen max-h-[800px] border rounded-lg overflow-hidden bg-white">
      <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
        <Viewer
          fileUrl={pdfUrl}
          plugins={[defaultLayoutPluginInstance]}
          onError={() => {
            setError('No se pudo visualizar el documento. Por favor, verifica que sea un archivo PDF válido.');
          }}
        />
      </Worker>
    </div>
  );
};