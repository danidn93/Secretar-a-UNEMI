import React, { useEffect, useState } from 'react';
import { PuntoOrden } from './components/PuntoOrden';
import { NuevoPunto } from './components/NuevoPunto';
import { useAgendaStore } from './store';
import { FileText, Save, AlertCircle, Check, CheckCircle, Building2 } from 'lucide-react';
import { DatosIniciales, RespuestaGuardado, TipoReunion } from './types';

function App() {
  const {
    puntos,
    agregarPunto,
    eliminarPunto,
    solicitarCambios,
    inicializarPuntos,
    limpiarPuntos,
    puntosOriginales,
  } = useAgendaStore();
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tipoReunion, setTipoReunion] = useState<TipoReunion>('CGA');
  const [mensaje, setMensaje] = useState<{ tipo: 'error' | 'success'; texto: string } | null>(null);
  const [guardadoExitoso, setGuardadoExitoso] = useState(false);

  const obtenerEstadoGeneral = () => {
    const hayPuntosNuevos = puntos.some(punto => 
      !puntosOriginales.find(original => original.id === punto.id)
    );

    const hayPuntosModificados = puntos.some(punto => {
      const puntoOriginal = puntosOriginales.find(original => original.id === punto.id);
      return punto.estado === 'eliminado' || 
             punto.estado === 'cambios_solicitados' ||
             punto.estado === 'agregado' ||
             (puntoOriginal && puntoOriginal.punto !== punto.punto);
    });

    return hayPuntosNuevos || hayPuntosModificados ? 'pending' : 'approved';
  };

  const mostrarMensaje = (tipo: 'error' | 'success', texto: string) => {
    setMensaje({ tipo, texto });
    setTimeout(() => setMensaje(null), 5000);
  };

  const cargarDatosIniciales = async (tipo: TipoReunion) => {
    setCargando(true);
    setError(null);
    setMensaje(null);
    setGuardadoExitoso(false);
    limpiarPuntos();
    try {
      const respuesta = await fetch('https://hook.us2.make.com/2ef74jbc24hme9l13e6abt1ys4o9paca', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tipo_reunion: tipo })
      });

      if (!respuesta.ok) {
        throw new Error('Error al conectar con el servidor');
      }

      const datos: DatosIniciales = await respuesta.json();

      if (Array.isArray(datos.orden_del_dia)) {
        inicializarPuntos(
          datos.orden_del_dia.map(item => ({
            numero: item.número,
            punto: item.punto,
          }))
        );
        mostrarMensaje('success', 'Datos cargados correctamente');
      } else {
        throw new Error('Formato de datos inválido');
      }
    } catch (error) {
      const mensaje = error instanceof Error ? error.message : 'Error al cargar los datos';
      mostrarMensaje('error', mensaje);
    } finally {
      setCargando(false);
    }
  };

  const handleTipoReunionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const nuevoTipo = event.target.value as TipoReunion;
    setTipoReunion(nuevoTipo);
    cargarDatosIniciales(nuevoTipo);
  };

  const handleGuardarCambios = async () => {
    setCargando(true);
    setMensaje(null);
    setGuardadoExitoso(false);
    try {
      const puntosActualizados = puntos.map(punto => {
        if (punto.estado === 'pendiente') {
          return { ...punto, estado: 'aprobado' };
        }
        return punto;
      });

      const puntosOrdenados = [...puntosActualizados].sort((a, b) => {
        const orden = {
          'aprobado': 1,
          'cambios_solicitados': 2,
          'eliminado': 3,
          'agregado': 4
        };
        return orden[a.estado] - orden[b.estado];
      });

      const respuesta = await fetch('https://hook.us2.make.com/2ycl4092ffxqrpitpipzlqc9a5gg74q6', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          tipo_reunion: tipoReunion,
          estado_general: obtenerEstadoGeneral(),
          puntos: puntosOrdenados.map(({ id, numero, punto, estado, cambios }) => ({
            id,
            numero,
            punto,
            estado,
            cambios: cambios || null,
          }))
        }),
      });

      if (!respuesta.ok) {
        throw new Error('Error al conectar con el servidor');
      }

      try {
        const resultado = await respuesta.json();
        if (typeof resultado.success === 'boolean') {
          if (resultado.success) {
            setGuardadoExitoso(true);
          } else {
            throw new Error(resultado.message || 'Error al guardar los cambios');
          }
        } else {
          setGuardadoExitoso(true);
        }
      } catch (jsonError) {
        setGuardadoExitoso(true);
      }
    } catch (error) {
      const mensaje = error instanceof Error ? error.message : 'Error al guardar los cambios';
      mostrarMensaje('error', mensaje);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => {
    cargarDatosIniciales(tipoReunion);
  }, []);

  const siguienteNumero = puntos.length > 0 
    ? Math.max(...puntos.map(p => p.numero)) + 1 
    : 1;

  // Ordenar los puntos según el criterio especificado para la visualización
  const puntosOrdenados = [...puntos].sort((a, b) => {
    const orden = {
      'aprobado': 1,
      'cambios_solicitados': 2,
      'eliminado': 3,
      'agregado': 4,
      'pendiente': 5
    };
    return (orden[a.estado] || 5) - (orden[b.estado] || 5);
  });

  if (guardadoExitoso) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F5F7FA' }}>
        <div className="text-center space-y-4 py-12">
          <CheckCircle className="w-16 h-16 text-[#006d2c] mx-auto" />
          <h2 className="text-2xl font-bold text-[#1C3247]">¡Enviado Exitosamente!</h2>
          <p className="text-gray-600">
            Muchas gracias!.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F5F7FA' }}>
      <header className="bg-[#1C3247] py-4">
        <div className="container mx-auto px-4 flex items-center gap-4">
          <Building2 size={48} className="text-white" />
          <span className="text-white font-aventura text-2xl">UNEMI</span>
        </div>
      </header>

      {mensaje && (
        <div 
          className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg flex items-center space-x-3 transition-all duration-500 ${
            mensaje.tipo === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200'
          }`}
        >
          {mensaje.tipo === 'error' ? (
            <AlertCircle className="h-5 w-5 text-red-500" />
          ) : (
            <div className="h-5 w-5 rounded-full bg-green-500 flex items-center justify-center">
              <Check className="h-3 w-3 text-white" />
            </div>
          )}
          <span className="font-medium">{mensaje.texto}</span>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-6 p-4 rounded-lg bg-white shadow-sm">
          <h2 className="text-xl font-semibold mb-4" style={{ color: '#1C3247' }}>
            Seleccionar Tipo de Reunión
          </h2>
          <div className="flex space-x-6">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="tipoReunion"
                value="CGA"
                checked={tipoReunion === 'CGA'}
                onChange={handleTipoReunionChange}
                className="w-4 h-4 text-blue-600"
              />
              <span className="text-lg" style={{ color: '#1C3247' }}>CGA</span>
            </label>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="tipoReunion"
                value="OCS"
                checked={tipoReunion === 'OCS'}
                onChange={handleTipoReunionChange}
                className="w-4 h-4 text-blue-600"
              />
              <span className="text-lg" style={{ color: '#1C3247' }}>OCS</span>
            </label>
          </div>
        </div>
        
        {cargando && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-xl">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto" style={{ borderColor: '#1C3247' }}></div>
              <p className="mt-4 text-center text-gray-700">Cargando...</p>
            </div>
          </div>
        )}
        
        <div>
          <h2 className="text-xl font-semibold mb-4" style={{ color: '#1C3247' }}>
            Puntos del Orden del Día
          </h2>
          <NuevoPunto onAgregar={agregarPunto} siguienteNumero={siguienteNumero} />
          <div className="space-y-4">
            {puntosOrdenados.map((punto) => (
              <PuntoOrden
                key={punto.id}
                punto={punto}
                onSolicitarCambios={solicitarCambios}
                onEliminar={eliminarPunto}
              />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;