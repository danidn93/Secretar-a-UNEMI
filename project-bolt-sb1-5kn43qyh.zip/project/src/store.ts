import { create } from 'zustand';
import { EstadoAgenda, PuntoOrden } from './types';

export const useAgendaStore = create<EstadoAgenda>((set, get) => ({
  puntos: [],
  puntosOriginales: [],
  agregarPunto: (nuevoPunto) =>
    set((state) => ({
      puntos: [
        ...state.puntos,
        {
          ...nuevoPunto,
          id: crypto.randomUUID(),
          estado: 'agregado',
        },
      ],
    })),
  eliminarPunto: (id) =>
    set((state) => ({
      puntos: state.puntos.map(punto => 
        punto.id === id 
          ? { ...punto, estado: 'eliminado' }
          : punto
      ),
    })),
  solicitarCambios: (id, cambios) =>
    set((state) => ({
      puntos: state.puntos.map((punto) =>
        punto.id === id
          ? { ...punto, estado: 'cambios_solicitados', cambios }
          : punto
      ),
    })),
  inicializarPuntos: (puntosIniciales) =>
    set((state) => {
      const puntos = puntosIniciales.map((punto) => ({
        id: crypto.randomUUID(),
        numero: punto.numero,
        punto: punto.punto,
        estado: 'pendiente',
      }));
      return {
        puntos,
        puntosOriginales: [...puntos],
      };
    }),
  limpiarPuntos: () => set({ puntos: [], puntosOriginales: [] }),
}));