import React, { useState, useRef, ChangeEvent, FormEvent } from 'react';
import { CheckCircle, Upload, File, X, Building2 } from 'lucide-react';

interface FileItem {
  file: File;
  preview?: string;
}

function App() {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<FileItem[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedOrgan, setSelectedOrgan] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const filesPromises = files.map(async (fileItem) => {
        const reader = new FileReader();
        const dataPromise = new Promise((resolve) => {
          reader.onload = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve(base64String);
          };
          reader.readAsDataURL(fileItem.file);
        });
        
        const data = await dataPromise;
        return {
          Filename: fileItem.file.name,
          data: data
        };
      });
      
      const filesData = await Promise.all(filesPromises);
      
      const payload = {
        organ: selectedOrgan,
        text: text,
        archivos: filesData
      };

      const response = await fetch('https://hook.us2.make.com/vp5keiusq6s0g11mrll4kvulq1o1l7nu', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setShowSuccess(true);
        setText('');
        setFiles([]);
        setSelectedOrgan('');
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files).map(file => ({
        file,
        preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined
      }));
      setFiles(prev => [...prev, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center space-y-4 py-12">
          <CheckCircle className="w-16 h-16 text-[#006d2c] mx-auto" />
          <h2 className="text-2xl font-bold text-[#1C3247]">¡Carga Realizada Exitosamente!</h2>
          <p className="text-gray-600">
            A continuación se procederá a realizar el tratamiento y operación con la información.
          </p>
          <button
            onClick={() => setShowSuccess(false)}
            className="mt-6 px-6 py-2 bg-[#fe9900] text-white rounded-lg hover:bg-[#e88a00] transition-colors"
          >
            Nuevo Registro
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#1C3247] py-4">
        <div className="container mx-auto px-4 flex items-center gap-4">
          <Building2 size={48} className="text-white" />
          <span className="text-white font-aventura text-2xl">UNEMI</span>
        </div>
      </header>

      <div className="p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-[#1C3247] mb-8">Sistema de Carga de Archivos</h1>
          
          <form onSubmit={handleSubmit} className="space-y-6 md:space-y-0 md:grid md:grid-cols-2 md:gap-6">
            {/* Left Column */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <label className="block mb-2 text-lg font-semibold text-[#1C3247]">
                  Órgano
                </label>
                <select
                  value={selectedOrgan}
                  onChange={(e) => setSelectedOrgan(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#006d2c] focus:border-transparent bg-white"
                  required
                >
                  <option value="">Seleccione un órgano</option>
                  <option value="OCS">Órgano Colegiado Superior (OCS)</option>
                  <option value="CGA">Comisión de Gestión Académica (CGA)</option>
                </select>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <label className="block mb-2 text-lg font-semibold text-[#1C3247]">
                  Texto Descriptivo
                </label>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="w-full h-[calc(100vh-450px)] min-h-[300px] p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#006d2c] focus:border-transparent"
                  placeholder="Ingrese su texto aquí..."
                  required
                />
              </div>
            </div>

            {/* Right Column */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <label className="block mb-4 text-lg font-semibold text-[#1C3247]">
                Archivos Adjuntos
              </label>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  multiple
                  className="hidden"
                  id="file-upload"
                  required
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer flex flex-col items-center"
                >
                  <Upload className="w-12 h-12 text-[#fe9900] mb-2" />
                  <span className="text-gray-600">Click para seleccionar archivos</span>
                </label>
              </div>

              {files.length > 0 && (
                <div className="mt-6 space-y-3 max-h-[calc(100vh-450px)] overflow-y-auto">
                  <h3 className="font-semibold text-[#1C3247] sticky top-0 bg-white py-2">
                    Archivos Seleccionados:
                  </h3>
                  {files.map((fileItem, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <File className="w-5 h-5 text-[#006d2c]" />
                        <span className="text-gray-700 truncate max-w-[300px]">
                          {fileItem.file.name}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-500 hover:text-red-700 flex-shrink-0"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Submit Button - Full Width */}
            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={isLoading || !selectedOrgan || !text || files.length === 0}
                className={`w-full py-3 px-6 text-white rounded-lg transition-colors ${
                  isLoading || !selectedOrgan || !text || files.length === 0
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-[#fe9900] hover:bg-[#e88a00]'
                }`}
              >
                {isLoading ? 'Procesando...' : 'Enviar'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;