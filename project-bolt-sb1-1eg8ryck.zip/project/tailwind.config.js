/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#1C3247',
        secondary: '#fe9900',
        accent: '#006d2c',
      },
      fontFamily: {
        aventura: ['AventuraHeavyBold', 'sans-serif'],
        avenir: ['Avenir LT Std', 'sans-serif'],
      },
    },
  },
  plugins: [],
};